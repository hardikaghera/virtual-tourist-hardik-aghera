//
//  FlickrClient.swift
//  virtual tourist 2.0
//
//  Created by hardik aghera on 27/11/16.
//  Copyright © 2016 hardik aghera. All rights reserved.
//

import Foundation

class FlickrClient: NSObject{
    
    static let shared = FlickrClient()
    
    private override init(){}
    
    func getPhotosByLocation(lat:Double, lon: Double, completionHandlerForGetPhotos: @escaping(_ errorString: String?, _ results: [String])-> Void){
        let methodParameters = [
            Constants.FlickrParameterKeys.Method: Constants.FlickrParameterValues.SearchMethod,
            Constants.FlickrParameterKeys.APIKey: Constants.FlickrParameterValues.APIKey,
            Constants.FlickrParameterKeys.SafeSearch: Constants.FlickrParameterValues.UseSafeSearch,
            Constants.FlickrParameterKeys.Extras: Constants.FlickrParameterValues.MediumURL,
            Constants.FlickrParameterKeys.Format: Constants.FlickrParameterValues.ResponseFormat,
            Constants.FlickrParameterKeys.NoJSONCallback: Constants.FlickrParameterValues.DisableJSONCallback,
            Constants.FlickrParameterKeys.PerPage: "21",
            Constants.FlickrParameterKeys.Lat: "\(lat)",
            Constants.FlickrParameterKeys.Lon: "\(lon)"
        ]
        
        let requestUrlString = Constants.Flickr.APIScheme + "://" + Constants.Flickr.APIHost + Constants.Flickr.APIPath
        
        performNetworkRequest(requestUrlString, methodParameters) { (results, error) in
            
            guard (error == nil) else {
                print("error performing request")
                return
            }
            
            guard let results = results else {
                print("results are nil")
                return
            }
            
            guard let photosDict = results[Constants.FlickrResponseKeys.Photos] as? [String:AnyObject] else {
                print("photos are nil")
                return
            }
            
            guard let photoDict = photosDict[Constants.FlickrResponseKeys.Photo] as? [[String:AnyObject]] else {
                print("photos is nil")
                return
            }
            
            var urlStringArray = [String]()
            
            for dict in photoDict{
                guard let urlString = dict[Constants.FlickrResponseKeys.MediumURL] as? String else {
                    print("no medium url in the dictionary")
                    return
                }
                urlStringArray.append(urlString)
                
            }
            completionHandlerForGetPhotos(nil, urlStringArray)
        }
    }
    
    func downloadImageData(urlString: String, completionHandlerForImageDataDownload:@escaping (_ imageData: Data?)->Void){
        
        guard let url = URL(string: urlString) else {
            print("url string is invalid")
            return
        }
        
        let imageDownloadQueue = DispatchQueue(label: "com.virtualtourist.app.downloadimage", qos: .background, target: nil)
        
        imageDownloadQueue.async {
            do {
                let imgData = try Data(contentsOf: url)
                DispatchQueue.main.async(){
                    completionHandlerForImageDataDownload(imgData)
                }
            } catch {
                print("call threw")
            }
        }
    }
    
}
