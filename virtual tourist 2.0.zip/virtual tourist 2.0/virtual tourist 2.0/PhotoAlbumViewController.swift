//
//  PhotoAlbumViewController.swift
//  virtual tourist 2.0
//
//  Created by hardik aghera on 27/11/16.
//  Copyright © 2016 hardik aghera. All rights reserved.
//

import UIKit
import MapKit

class PhotoAlbumViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    
    var selectedCoordinate: CLLocationCoordinate2D!
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var newCollectionButton: UIBarButtonItem!
    @IBOutlet var noPhotosLabel: UILabel!
    
    var deleteSelected = false
    var numberOfCells = 0
    var numberOfLoadedPhotos = 0
    
    var loadingFromFlickr = false
    
    let coreDataClient = CoreDataClient.shared
    let flickrClient = FlickrClient.shared
    var selectedPin:Pin!
    
    var photoData = [Photo]()
    var urlStrings = [String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        collectionView.dataSource = self
        collectionView.delegate = self
        adjustSize()
    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        setUpMiniMap(selectedCoordinate: selectedCoordinate)
        super.viewDidAppear(animated)
        checkPhotosForPin()
    }
    
    func checkPhotosForPin(){
        
        if let pin = coreDataClient.getSelectedPinFromCoreData(selectedCoordinate.latitude, lon: selectedCoordinate.longitude){
            selectedPin = pin
            photoData = coreDataClient.loadPhotosFromCoreDataForSelectedPin(pin)
            if photoData.count > 0 {
                numberOfCells = photoData.count
                collectionView.reloadData()
                print("numberOfCells:\(numberOfCells)")
                newCollectionButton.isEnabled = true
            } else {
                
                getPhotosUrls()
            }
        }
    }
    
    func getPhotosUrls(){
        flickrClient.getPhotosByLocation(lat: selectedCoordinate.latitude, lon: selectedCoordinate.longitude, completionHandlerForGetPhotos: { (error, urls) in
            guard (error == nil) else {
                print("completionHandlerForGetPhotos error")
                return
            }
            
            if urls.count == 0{
                self.noPhotosLabel.isHidden = false
                print("no photos at this location")
            } else {
                
                self.numberOfCells = urls.count
                self.urlStrings = urls
                self.loadingFromFlickr = true
                self.collectionView.reloadData()
            }
        })
    }
    
    
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "imageCell", for: indexPath) as! CollectionViewCell
        cell.acivityIndicator.startAnimating()
        
        if loadingFromFlickr{
            
            flickrClient.downloadImageData(urlString: urlStrings[indexPath.row], completionHandlerForImageDataDownload: { (data) in
                guard let data = data else {
                    print("completionHandlerForImageDataDownload data is nil")
                    return
                }
                let photo = self.coreDataClient.saveImageToCoreData(imgData: data, selectedPin: self.selectedPin)
                self.photoData.append(photo)
                
                if let image = UIImage(data: data){
                    cell.imageView.image = image
                    cell.acivityIndicator.stopAnimating()
                    
                    // all photos are loaded?
                    if self.photoData.count == self.numberOfCells{
                        self.newCollectionButton.isEnabled = true
                        self.loadingFromFlickr = false
                    }
                }
            })
            
        } else {
            if let image = coreDataClient.loadImageFromCoreData(index: indexPath.row, photoData: photoData){
                cell.imageView.image = image
                cell.acivityIndicator.stopAnimating()
            }
        }
        
        return cell
    }
    
    func activateNewCollectionButton(){
        if self.numberOfLoadedPhotos == numberOfCells {
            // we loaded all the photos:
            newCollectionButton.isEnabled = true
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return numberOfCells
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        // making sure we are not trying to delete anything while it's stil loading
        if (loadingFromFlickr == false){
            let removedPhoto = photoData.remove(at: indexPath.row)
            coreDataClient.deletePhotos([removedPhoto])
            numberOfCells = photoData.count
            collectionView.deleteItems(at: [indexPath])
        }
        
    }
    
    // MARK: Collection view settings
    
    func adjustSize(){
        let flow = collectionView.collectionViewLayout as! UICollectionViewFlowLayout
        flow.sectionInset = UIEdgeInsetsMake(0, 0, 0, 0)
        let width = UIScreen.main.bounds.size.width - 6
        flow.itemSize = CGSize(width: width/3, height: width/3)
        flow.minimumInteritemSpacing = 3
        flow.minimumLineSpacing = 3
    }
    
    func setUpMiniMap(selectedCoordinate:CLLocationCoordinate2D!){
        let annotation = MKPointAnnotation()
        let coordinateMap = CLLocationCoordinate2D(latitude: selectedCoordinate.latitude, longitude: selectedCoordinate.longitude)
        annotation.coordinate = coordinateMap
        
        let latDelta:CLLocationDegrees = 0.1
        let lonDelta:CLLocationDegrees = 0.1
        let span = MKCoordinateSpanMake(latDelta, lonDelta)
        let region = MKCoordinateRegionMake(coordinateMap, span)
        mapView.addAnnotation(annotation)
        mapView.setRegion(region, animated: false)
    }
    
    
    @IBAction func showNewCollection(_ sender: Any) {
        coreDataClient.deletePhotos(photoData)
        photoData = []
        getPhotosUrls()
    }
}
