//
//  NetworkRequest.swift
//  virtual tourist 2.0
//
//  Created by hardik aghera on 27/11/16.
//  Copyright © 2016 hardik aghera. All rights reserved.
//

import Foundation

public func performNetworkRequest(_ requestUrlString:String,_ parameters: [String:String], completionHandlerForNetworkRequest: @escaping (_ result: AnyObject?, _ error: NSError?) -> Void){
    
    /* 1. Set the parameters */
    var urlString = requestUrlString
    
    
    urlString += "?"
    for (number, dict) in parameters.enumerated(){
        if number != (parameters.count - 1) {
            urlString += "\(dict.key)=\(dict.value)&"
        } else {
            urlString += "\(dict.key)=\(dict.value)"
        }
    }
    
    
    
    /* 2/3. Build the URL, Configure the request */
    
    guard let url = URL(string: urlString) else {
        print("cannot set the url")
        return
    }
    
    let request = NSMutableURLRequest(url: url)
    
    
    
    /* 4. Make the request */
    let task = URLSession.shared.dataTask(with: request as URLRequest) { (data, response, error) in
        
        func sendError(_ error: String) {
            
            let userInfo = [NSLocalizedDescriptionKey : error]
            
            DispatchQueue.main.sync {
                completionHandlerForNetworkRequest(nil, NSError(domain: "networkRequest", code: 1, userInfo: userInfo))
            }
        }
        
        /* GUARD: Was there an error? */
        guard (error == nil) else {
            if let description = error?.localizedDescription{
                sendError("Connection error: \(description)")
            }
            return
        }
        
        /* GUARD: Did we get a successful 2XX response? */
        
        guard let statusCode = (response as? HTTPURLResponse)?.statusCode else {
            sendError("Coudln't extract the status code")
            return
        }
        
        if statusCode == 403 {
            sendError("Incorrect login credentials")
            return
        }
        if statusCode <= 200 && statusCode >= 299 {
            sendError("Your request returned a status code other than 2xx!")
            return
        }
        
        /* GUARD: Was there any data returned? */
        guard let data = data else {
            sendError("No data was returned by the request!")
            return
        }
        
        DispatchQueue.main.sync {
            /* 5/6. Parse the data and use the data (happens in completion handler) */
            convertDataWithCompletionHandler(data, completionHandlerForConvertData: completionHandlerForNetworkRequest)
        }
    }
    
    /* 7. Start the request */
    task.resume()
}

// given raw JSON, return a usable Foundation object
private func convertDataWithCompletionHandler(_ data: Data, completionHandlerForConvertData: (_ result: AnyObject?, _ error: NSError?) -> Void) {
    
    var parsedResult: AnyObject! = nil
    do {
        parsedResult = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as AnyObject
    } catch {
        let userInfo = [NSLocalizedDescriptionKey : "Could not parse the data as JSON: '\(data)'"]
        completionHandlerForConvertData(nil, NSError(domain: "convertDataWithCompletionHandler", code: 1, userInfo: userInfo))
    }
    
    completionHandlerForConvertData(parsedResult, nil)
}
