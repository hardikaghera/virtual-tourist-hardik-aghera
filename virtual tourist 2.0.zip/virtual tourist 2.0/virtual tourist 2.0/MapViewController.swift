//
//  MapViewController.swift
//  virtual tourist 2.0
//
//  Created by hardik aghera on 27/11/16.
//  Copyright © 2016 hardik aghera. All rights reserved.
//

import UIKit
import MapKit

class MapViewController: UIViewController, MKMapViewDelegate {
    
    
    // Get the stack
    let delegate = UIApplication.shared.delegate as! AppDelegate
    
    let flickrClient = FlickrClient.shared
    let coreDataClient = CoreDataClient.shared
    
    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var editAndDoneButton: UIBarButtonItem!
    
    var selectedCoordinate: CLLocationCoordinate2D!
    
    
    @IBOutlet weak var tapPinsToDeleteLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        mapView.delegate = self
        
        let dropPinGestureRecognizer = UILongPressGestureRecognizer(target: self, action: #selector(dropPin(dropPinGestureRecognizer:)))
        mapView.addGestureRecognizer(dropPinGestureRecognizer)
        
        
        let pins = coreDataClient.getPins()
        mapView.addAnnotations(pins)
        
    }
    
    
    @IBAction func edit(_ sender: UIBarButtonItem) {
        
        if tapPinsToDeleteLabel.isHidden == true {
            // Switching to the pin deletion mode if there are pins on the map:
            if mapView.annotations.count > 0{
                sender.title = "Done"
                tapPinsToDeleteLabel.isHidden = false
            } else {
                presentAlert(title: "Deleting pins", message: "Nothing to delete", viewController: self, completion: nil)
            }
            // Turning the pin deletion mode off:
        } else {
            sender.title = "Edit"
            tapPinsToDeleteLabel.isHidden = true
        }
    }
    
    func dropPin(dropPinGestureRecognizer:UILongPressGestureRecognizer){
        // after the touch was recognized as long press and we are not in pin deleting mode
        if (dropPinGestureRecognizer.state == .began) && (tapPinsToDeleteLabel.isHidden){
            let touchPoint = dropPinGestureRecognizer.location(in: mapView)
            let touchCoordinate = mapView.convert(touchPoint, toCoordinateFrom: mapView)
            let annotation = MKPointAnnotation()
            annotation.coordinate = touchCoordinate
            mapView.addAnnotation(annotation)
            coreDataClient.storePin(lat: Double(touchCoordinate.latitude), lon: Double(touchCoordinate.longitude))
        }
    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        let reuseId = "pin"
        var pinView = mapView.dequeueReusableAnnotationView(withIdentifier: reuseId) as? MKPinAnnotationView
        
        if pinView == nil {
            pinView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: reuseId)
            pinView!.pinTintColor = .red
            pinView?.animatesDrop = true
        }
        else {
            pinView!.annotation = annotation
        }
        
        return pinView
    }
    
    // MARK: pin tapped
    func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
        if let annotation = view.annotation{
            if tapPinsToDeleteLabel.isHidden == true{
                selectedCoordinate = annotation.coordinate
                performSegue(withIdentifier: "openDetailedView", sender: self)
                mapView.deselectAnnotation(view.annotation, animated: false)
            } else {
                coreDataClient.deletePin(coordinate: annotation.coordinate)
                // delete pin
                mapView.removeAnnotation(annotation)
                if mapView.annotations.count == 0{
                    editAndDoneButton.title = "Edit"
                    tapPinsToDeleteLabel.isHidden = true
                }
                
            }
        } else {
            print("can't unwrap view.annotation")
        }
    }
    
    
    
    // MARK: - Navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "openDetailedView"{
            let detailVC = segue.destination as? PhotoAlbumViewController
            detailVC?.selectedCoordinate = selectedCoordinate
        }
    }
    
}
