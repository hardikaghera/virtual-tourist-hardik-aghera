//
//  CollectionViewCell.swift
//  virtual tourist 2.0
//
//  Created by hardik aghera on 27/11/16.
//  Copyright © 2016 hardik aghera. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var acivityIndicator: UIActivityIndicatorView!
    @IBOutlet weak var imageView: UIImageView!
    var imgUrl:String!
    var shouldBeDeleted = false
}
