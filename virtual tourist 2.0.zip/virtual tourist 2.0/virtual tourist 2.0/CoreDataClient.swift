//
//  CoreDataClient.swift
//  virtual tourist 2.0
//
//  Created by hardik aghera on 27/11/16.
//  Copyright © 2016 hardik aghera. All rights reserved.
//

import UIKit
import CoreData
import MapKit

class CoreDataClient: NSObject{
    
    static let shared = CoreDataClient()
    
    let stack = CoreDataStack(modelName: "Model")!
    let context:NSManagedObjectContext
    
    private override init() {
        context = stack.context
    }
    
    // MARKK: Map view
    
    
    
    func getPins()->[MKPointAnnotation] {
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Pin")
        var pins = [MKPointAnnotation]()
        
        do {
            //go get the results
            let searchResults = try context.fetch(fetchRequest)
            
            //You need to convert to NSManagedObject to use 'for' loops
            for pin in searchResults as! [NSManagedObject] {
                //get the Key Value pairs (although there may be a better way to do that...
                
                guard let lat = pin.value(forKey: "lat") as? CLLocationDegrees else{
                    print("lat is nil")
                    break
                }
                
                guard let lon = pin.value(forKey: "lon") as? CLLocationDegrees else{
                    print("lon is nil")
                    break
                }
                
                let annotation = MKPointAnnotation()
                annotation.coordinate = CLLocationCoordinate2D(latitude: lat, longitude: lon)
                pins.append(annotation)
            }
            
        } catch {
            print("Error with request: \(error)")
        }
        return pins
    }
    
    
    func storePin(lat:Double, lon:Double) {
        let pn = Pin(context: stack.context)
        pn.lat = lat
        pn.lon = lon
        
        saveContextAsync()
    }
    
    
    func deletePin(coordinate: CLLocationCoordinate2D){
        
        if let pinToDelete = getSelectedPinFromCoreData(coordinate.latitude , lon: coordinate.longitude) {
            context.delete(pinToDelete)
            //save the object
            saveContextAsync()
        }
    }
    
    
    
    // MARK: PhotoAlbum
    
    func saveContextAsync(){
        let saveContextQueue = DispatchQueue(label: "com.app.queue",
                                             qos: .background,
                                             target: nil)
        saveContextQueue.async {
            do {
                try self.stack.context.save()
            } catch let error as NSError  {
                print("Could not save \(error), \(error.userInfo)")
            }
        }
    }
    
    func loadPhotosFromCoreDataForSelectedPin(_ selectedPin: Pin) -> [Photo]{
        
        let fetchPhotosRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Photo")
        fetchPhotosRequest.predicate = NSPredicate(format: "pin == %@", selectedPin)
        if let photos = try? context.fetch(fetchPhotosRequest) as! [Photo] {
            return photos
        }
        
        return []
    }
    
    func getSelectedPinFromCoreData(_ lat:Double, lon:Double) -> Pin?{
        let fetchPinRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Pin")
        
        fetchPinRequest.predicate = NSPredicate(format: "lat == %lf AND lon == %lf", lat, lon)
        
        if let pins = try? context.fetch(fetchPinRequest) as! [Pin]{
            if pins.count == 1{
                return pins[0]
            } else {
                print("getSelectedPinFromCoreData: There are multiple pins with the same coordiante")
            }
        }
        return nil
    }
    
    func loadImageFromCoreData(index:Int, photoData:[Photo]) -> (UIImage?){
        
        let photo = photoData[index]
        let imgData = photo.imgData
        
        if let image = UIImage(data: imgData as! Data) {
            return image
        } else {
            return nil
        }
    }
    
    
    func saveImageToCoreData(imgData:Data, selectedPin:Pin) -> Photo{
        
        let photo = Photo(context: stack.context)
        photo.imgData = imgData as NSData?
        
        selectedPin.addToPhotos(photo)
        return photo
    }
    
    
    
    func deleteAllPhotosForPin(_ selectedPin: Pin){
        let photos = loadPhotosFromCoreDataForSelectedPin(selectedPin)
        for photo in photos{
            context.delete(photo)
        }
        saveContextAsync()
    }
    
    func deletePhotos(_ photos: [Photo]){
        for photo in photos{
            context.delete(photo)
        }
        saveContextAsync()
    }
    
    
}
