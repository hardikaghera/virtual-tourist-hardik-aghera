//
//  Alertview.swift
//  virtual tourist 2.0
//
//  Created by hardik aghera on 27/11/16.
//  Copyright © 2016 hardik aghera. All rights reserved.
//

import UIKit
import Foundation

func presentAlert(title: String, message: String, viewController: UIViewController, completion:(()->Void)?){
    
    let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.alert)
    alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
    
    viewController.present(alert, animated: true) {
        if let completion = completion{
            completion()
        }
    }
}
